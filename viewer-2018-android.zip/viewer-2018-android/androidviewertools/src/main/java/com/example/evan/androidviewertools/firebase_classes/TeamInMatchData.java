package com.example.evan.androidviewertools.firebase_classes;


import java.util.ArrayList;
import java.util.Map;

public class TeamInMatchData {
	public Integer teamNumber;
	public Integer matchNumber;


}