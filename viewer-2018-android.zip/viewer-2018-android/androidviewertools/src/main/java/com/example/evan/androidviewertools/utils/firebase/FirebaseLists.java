package com.example.evan.androidviewertools.utils.firebase;

import com.example.evan.androidviewertools.firebase_classes.Match;
import com.example.evan.androidviewertools.firebase_classes.Team;
import com.example.evan.androidviewertools.firebase_classes.TeamInMatchData;

public class FirebaseLists {
    public static FirebaseList<Team> teamsList;
    public static FirebaseList<Match> matchesList;
    public static FirebaseList<TeamInMatchData> teamInMatchDataList;
}
