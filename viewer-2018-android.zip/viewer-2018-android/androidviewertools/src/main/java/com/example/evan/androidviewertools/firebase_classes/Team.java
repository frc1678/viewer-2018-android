package com.example.evan.androidviewertools.firebase_classes;


import java.util.List;
import java.util.Map;


public class Team {

	public String name;
 	public Integer number;
 	public List<Match> matches;
 	public List<TeamInMatchData> teamInMatchDatas;
 	public String selectedImageUrl;

}
