package com.example.evan.androidviewertools.firebase_classes;

import java.util.List;


public class Match {
	public Integer number;
	public List<Integer> redAllianceTeamNumbers;
	public List<Integer> blueAllianceTeamNumbers;
	public Integer redScore;
	public Integer blueScore;
}