package com.example.evan.androidviewertemplates.utils;

import com.example.evan.androidviewertools.utils.NavigationDrawerFragment;


public class SpecificNavigationDrawerFragment extends NavigationDrawerFragment {
    @Override
    public String[] getDrawerTitles() {
        return SpecificConstants.DRAWER_TITLES;
    }
}

