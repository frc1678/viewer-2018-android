package com.example.evan.androidviewertemplates.utils;

import com.example.evan.androidviewertools.utils.Constants;

/**
 * Created by Teo on 2/4/2018.
 */

public class Util {

    public static void setAllSortConstantsFalse(){
        Constants.sortByTeamNumber = false;
        Constants.sortByRank = false;
        Constants.sortByFirstPick = false;
        Constants.sortBySecondPick = false;
    }
}
